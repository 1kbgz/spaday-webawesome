import ast
from pathlib import Path

from spaday import Token, element, generate
from spaday.bootstrap import bootstrap

from spaday_webawesome import TOKENS, Tabs, WaButton, WaCard, package


def _generated_ast(source: str) -> str:
    class Normalize(ast.NodeTransformer):
        def visit_ImportFrom(self, node):
            if node.module == "typing":
                node.names = [name for name in node.names if name.name != "Optional"]
            return node

        def visit_Subscript(self, node: ast.Subscript):
            self.generic_visit(node)
            if isinstance(node.value, ast.Name) and node.value.id == "Optional":
                return ast.BinOp(left=node.slice, op=ast.BitOr(), right=ast.Constant(value=None))
            return node

        def visit_Assign(self, node: ast.Assign):
            self.generic_visit(node)
            if any(isinstance(target, ast.Name) and target.id == "__all__" for target in node.targets):
                assert isinstance(node.value, ast.List)
                node.value.elts.sort(key=ast.unparse)
            return node

    return ast.dump(Normalize().visit(ast.parse(source)))


def test_generated_components_serialize():
    node = WaCard(WaButton(variant="brand").text("Run")).to_node()
    assert node["tag"] == "wa-card"
    assert node["slots"]["default"][0]["tag"] == "wa-button"


def test_tabs_build_linked_headers_and_panels():
    node = Tabs().tab("Overview", element("p")).to_node()
    assert node["slots"]["nav"][0]["props"]["panel"] == {"Str": "overview"}
    assert node["slots"]["default"][0]["props"]["name"] == {"Str": "overview"}


def test_package_drives_bootstrap_asset_urls():
    html = bootstrap(packages=[package])
    tags = {schema.tag for schema in package.catalog}
    assert {"wa-button", "wa-card", "wa-input"} <= tags
    assert len(tags) == len(package.catalog)
    assert 'href="/components/webawesome/css/webawesome.css"' in html
    assert 'src="/components/webawesome/cdn/index.js"' in html


def test_package_publishes_webawesome_under_its_own_specifiers():
    html = bootstrap(packages=[package])
    assert '"@awesome.me/webawesome/dist/": "/components/webawesome/vendor/@awesome.me/webawesome/dist/"' in html
    # the bundle's own imports resolve through the map, so it must come first
    assert html.index('type="importmap"') < html.index('src="/components/webawesome/cdn/index.js"')


def test_published_imports_are_served():
    for specifier, path in package.imports:
        target = package.assets_dir / path
        assert target.is_dir() if path.endswith("/") else target.is_file(), f"{specifier} maps to {path}, which the build did not produce"


def test_tokens_are_structured_webawesome_tokens():
    for kwarg, token in TOKENS.items():
        assert isinstance(token, Token)
        prop, description = token
        assert prop == f"--{kwarg.replace('_', '-')}" and description.startswith("drives --spa-")

    css = (Path(__file__).parents[2] / "js/src/css/webawesome.css").read_text(encoding="utf-8")
    assert "--spa-text: var(--wa-color-text-normal);" in css


def test_generated_catalog_is_current():
    root = Path(__file__).parent.parent
    fresh = generate(str(root / "custom-elements.json"))
    assert _generated_ast(fresh) == _generated_ast((root / "components.py").read_text(encoding="utf-8"))


def test_radio_orientation_is_a_generated_enum():
    from spaday import validate

    from spaday_webawesome import WaRadio, WaRadioGroup

    group = WaRadioGroup(WaRadio(value="one").text("One"), orientation="horizontal")
    assert group.to_node()["props"]["orientation"] == {"Str": "horizontal"}
    validate(group)
    assert WaRadioGroup.schema is not None
    prop = next(prop for prop in WaRadioGroup.schema.props if prop.name == "orientation")
    assert prop.choices == ("horizontal", "vertical")


def test_autocomplete_exposes_input_props_and_suggestion_contract():
    from spaday_webawesome import Autocomplete

    control = Autocomplete(suggestions_url="/api/symbols", allow_custom=False, label="Symbol", required=True).bind("value", "symbol", mode="two-way")
    node = control.to_node()
    assert node["tag"] == "spaday-wa-autocomplete"
    assert node["props"]["suggestions-url"] == {"Str": "/api/symbols"}
    assert node["props"]["allow-custom"] == {"Bool": False}
    assert node["props"]["label"] == {"Str": "Symbol"}
    assert node["props"]["required"] == {"Bool": True}
    assert any(schema.tag == control.tag for schema in package.catalog)
    assert control.schema is not None
    assert {"suggestions-url", "allow-custom", "value", "name", "label"} <= {prop.name for prop in control.schema.props}
    assert {"input", "change", "suggestions-error"} <= set(control.schema.events)
