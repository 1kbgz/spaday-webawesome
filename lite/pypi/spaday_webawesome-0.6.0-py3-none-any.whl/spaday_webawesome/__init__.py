import json
from pathlib import Path

from spaday import ComponentPackage, Token

from . import components as _components
from .components import *
from .components import __all__ as _component_names
from .design import DESIGN
from .form import FormField, form
from .tabs import Tabs

__version__ = "0.6.0"

# the exact version of each JS library the package serves, written by its JS build
_VERSIONS = Path(__file__).parent / "extension" / "versions.json"

package = ComponentPackage(
    name="webawesome",
    assets_dir=Path(__file__).parent / "extension",
    assets=(("css", "css/webawesome.css"), ("js", "cdn/index.js")),
    components=tuple(getattr(_components, name) for name in _component_names),
    # WebAwesome's modules under its own bare specifiers: a library on the page that imports
    # WebAwesome resolves to this copy instead of registering the same tags a second time
    imports=(
        ("@awesome.me/webawesome", "vendor/@awesome.me/webawesome/dist/webawesome.js"),
        ("@awesome.me/webawesome/dist/", "vendor/@awesome.me/webawesome/dist/"),
    ),
    provides=json.loads(_VERSIONS.read_text(encoding="utf-8")) if _VERSIONS.exists() else {},
    # how the generic controls of spaday.ui render here (see design.py)
    design=DESIGN,
)

#: ``css()`` kwarg → (CSS custom property, what it controls), in the shape of
#: :data:`spaday.theme.SHELL_TOKENS`.
#:
#: WebAwesome is a design system, so this package themes the *other* way round from a rendering
#: package: rather than exposing ``--spa-webawesome-*`` tokens of its own, its stylesheet maps
#: WebAwesome's tokens onto the ``--spa-*`` palette that spaday's shell and every other component
#: package reads. Set these and the whole page follows — shell, graphs, tables, trees::
#:
#:     App().css(wa_color_brand_fill_loud="#0C4253")
#:
#: Every other WebAwesome token works the same way (``css()`` takes arbitrary custom properties);
#: these are the ones wired to the shell palette.
TOKENS = {
    "wa_color_surface_default": Token("--wa-color-surface-default", "drives --spa-surface"),
    "wa_color_surface_lowered": Token("--wa-color-surface-lowered", "drives --spa-surface-2"),
    "wa_color_surface_border": Token("--wa-color-surface-border", "drives --spa-border"),
    "wa_color_text_quiet": Token("--wa-color-text-quiet", "drives --spa-muted"),
    "wa_color_brand_fill_loud": Token("--wa-color-brand-fill-loud", "drives --spa-accent and --spa-info"),
    "wa_color_success_fill_loud": Token("--wa-color-success-fill-loud", "drives --spa-success"),
    "wa_color_warning_fill_loud": Token("--wa-color-warning-fill-loud", "drives --spa-warning"),
    "wa_color_danger_fill_loud": Token("--wa-color-danger-fill-loud", "drives --spa-danger"),
}

__all__ = [*_component_names, "DESIGN", "FormField", "TOKENS", "Tabs", "form", "package"]  # noqa: PLE0604
