import asyncio
import re

import httpx

from spaday_webawesome import components, gallery


def _tags(value):
    if isinstance(value, dict):
        if isinstance(value.get("tag"), str):
            yield value["tag"]
        for child in value.values():
            yield from _tags(child)
    elif isinstance(value, list):
        for child in value:
            yield from _tags(child)


def test_gallery_shows_every_generated_component_with_a_snippet():
    expected_names = set(components.__all__)
    expected_tags = {getattr(components, name).tag for name in expected_names}
    gallery_tags = {tag for tag in _tags(gallery.page.to_node()) if tag.startswith("wa-")}
    snippet_names = set(re.findall(r"\bWa[A-Z][A-Za-z]+\b", "\n".join(gallery.COMPONENT_SNIPPETS)))

    assert gallery_tags == expected_tags
    assert snippet_names == expected_names


def test_gallery_app_serves_the_component_tree():
    async def request():
        transport = httpx.ASGITransport(app=gallery.app)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            return await client.get("/tree.json")

    response = asyncio.run(request())
    assert response.status_code == 200
    assert "wa-zoomable-frame" in response.text


def test_reactive_tree_uses_direct_repeaters():
    tree = gallery.page.to_node()
    repeaters = [value for value in _nodes(tree) if value.get("tag") == "spa-each"]

    assert len(repeaters) == 2
    assert all(repeater["props"]["direct"] == {"Bool": True} for repeater in repeaters)


def _nodes(value):
    if isinstance(value, dict):
        if isinstance(value.get("tag"), str):
            yield value
        for child in value.values():
            yield from _nodes(child)
    elif isinstance(value, list):
        for child in value:
            yield from _nodes(child)
